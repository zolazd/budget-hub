from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
REL_NS = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}


def col_to_num(col: str) -> int:
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - 64)
    return n


def num_to_col(n: int) -> str:
    out = ""
    while n:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


def cell_parts(ref: str) -> tuple[int, int]:
    m = re.match(r"([A-Z]+)([0-9]+)", ref)
    return int(m.group(2)), col_to_num(m.group(1))


def read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    strings = []
    for si in root.findall("m:si", NS):
        chunks = [t.text or "" for t in si.findall(".//m:t", NS)]
        strings.append("".join(chunks))
    return strings


def read_sheet_map(zf: zipfile.ZipFile) -> dict[str, str]:
    wb = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_map = {
        rel.attrib["Id"]: "xl/" + rel.attrib["Target"].lstrip("/")
        for rel in rels.findall("r:Relationship", REL_NS)
    }
    sheets = {}
    for sheet in wb.findall("m:sheets/m:sheet", NS):
        name = sheet.attrib["name"].strip()
        rid = sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
        sheets[name] = rel_map[rid]
    return sheets


def sheet_cells(zf: zipfile.ZipFile, path: str, shared: list[str]) -> dict[str, object]:
    root = ET.fromstring(zf.read(path))
    cells = {}
    for c in root.findall(".//m:c", NS):
        ref = c.attrib.get("r")
        typ = c.attrib.get("t")
        formula = c.find("m:f", NS)
        v = c.find("m:v", NS)
        if not ref:
            continue
        value = None
        if typ == "s" and v is not None:
            idx = int(v.text)
            value = shared[idx] if idx < len(shared) else None
        elif typ == "inlineStr":
            value = "".join(t.text or "" for t in c.findall(".//m:t", NS))
        elif v is not None:
            text = v.text
            try:
                num = float(text)
                value = int(num) if num.is_integer() else num
            except (TypeError, ValueError):
                value = text
        if formula is not None and formula.text:
            cells[ref] = {"formula": formula.text, "value": value}
        elif value not in (None, ""):
            cells[ref] = value
    return cells


def range_values(cells: dict[str, object], start: str, end: str) -> list[list[object]]:
    sr, sc = cell_parts(start)
    er, ec = cell_parts(end)
    rows = []
    for r in range(sr, er + 1):
        row = []
        for c in range(sc, ec + 1):
            row.append(cells.get(f"{num_to_col(c)}{r}", ""))
        rows.append(row)
    return rows


def nonempty_rows(rows: list[list[object]]) -> list[list[object]]:
    return [row for row in rows if any(v != "" for v in row)]


def main() -> None:
    path = Path(sys.argv[1])
    out = {}
    with zipfile.ZipFile(path) as zf:
        shared = read_shared_strings(zf)
        sheets = read_sheet_map(zf)
        out["sheets"] = list(sheets)
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        out["months"] = {}
        for month in month_names:
            if month not in sheets:
                continue
            cells = sheet_cells(zf, sheets[month], shared)
            out["months"][month] = {
                "header": nonempty_rows(range_values(cells, "A1", "V30")),
                "trackers": {
                    "bills": nonempty_rows(range_values(cells, "AJ18", "AO140"))[:35],
                    "categories": nonempty_rows(range_values(cells, "AT104", "BU124")),
                    "summary": nonempty_rows(range_values(cells, "A31", "V120"))[:50],
                    "transactions": nonempty_rows(range_values(cells, "I7", "M102"))[:40],
                },
            }
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
