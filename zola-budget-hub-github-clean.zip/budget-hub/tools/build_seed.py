from __future__ import annotations

import json
import re
import sys
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
REL_NS = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}

MONTHS = [
    ("Jan", "January", 1),
    ("Feb", "February", 2),
    ("Mar", "March", 3),
    ("Apr", "April", 4),
    ("May", "May", 5),
    ("Jun", "June", 6),
    ("Jul", "July", 7),
    ("Aug", "August", 8),
    ("Sep", "September", 9),
    ("Oct", "October", 10),
    ("Nov", "November", 11),
    ("Dec", "December", 12),
]


def col_to_num(col: str) -> int:
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - 64)
    return n


def num_to_col(n: int) -> str:
    out = ""
    while n:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


def unwrap(value):
    if isinstance(value, dict):
        return value.get("value")
    return value


def excel_date(serial) -> str | None:
    if not isinstance(serial, (int, float)):
        return None
    # Excel's 1900 date system includes the historical leap-year bug.
    return (date(1899, 12, 30) + timedelta(days=int(serial))).isoformat()


def read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    strings = []
    for si in root.findall("m:si", NS):
        strings.append("".join(t.text or "" for t in si.findall(".//m:t", NS)).strip())
    return strings


def read_sheet_map(zf: zipfile.ZipFile) -> dict[str, str]:
    wb = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_map = {
        rel.attrib["Id"]: "xl/" + rel.attrib["Target"].lstrip("/")
        for rel in rels.findall("r:Relationship", REL_NS)
    }
    sheets = {}
    for sheet in wb.findall("m:sheets/m:sheet", NS):
        name = sheet.attrib["name"].strip()
        rid = sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
        sheets[name] = rel_map[rid]
    return sheets


def read_cells(zf: zipfile.ZipFile, path: str, shared: list[str]) -> dict[str, object]:
    root = ET.fromstring(zf.read(path))
    cells = {}
    for c in root.findall(".//m:c", NS):
        ref = c.attrib.get("r")
        typ = c.attrib.get("t")
        v = c.find("m:v", NS)
        formula = c.find("m:f", NS)
        value = None
        if typ == "s" and v is not None:
            idx = int(v.text)
            value = shared[idx] if idx < len(shared) else None
        elif typ == "inlineStr":
            value = "".join(t.text or "" for t in c.findall(".//m:t", NS)).strip()
        elif v is not None and v.text is not None:
            try:
                num = float(v.text)
                value = int(num) if num.is_integer() else round(num, 2)
            except ValueError:
                value = v.text
        if formula is not None and formula.text:
            cells[ref] = {"formula": formula.text, "value": value}
        elif value not in (None, ""):
            cells[ref] = value
    return cells


def cell(cells: dict[str, object], ref: str):
    return unwrap(cells.get(ref, ""))


def read_transaction_rows(cells: dict[str, object], month_index: int) -> list[dict[str, object]]:
    rows = []
    for row in range(19, 169):
        raw_date = cell(cells, f"AJ{row}")
        category = str(cell(cells, f"AK{row}") or "").strip()
        subcategory = str(cell(cells, f"AL{row}") or "").strip()
        amount = cell(cells, f"AN{row}")
        description = str(cell(cells, f"AO{row}") or "").strip()
        if not category and not subcategory and not amount:
            continue
        if category.lower() in {"category", "summary"}:
            continue
        if not isinstance(amount, (int, float)):
            continue
        when = excel_date(raw_date) or f"2026-{month_index:02d}-25"
        rows.append(
            {
                "id": f"seed-{month_index:02d}-{row}",
                "date": when,
                "account": "Deposits (Credit Union)",
                "category": category or "Uncategorized",
                "subcategory": subcategory or category or "Uncategorized",
                "amount": round(float(amount), 2),
                "description": description,
                "sourceMonth": month_index,
            }
        )
    return rows


def read_budgets(cells: dict[str, object], month_index: int) -> list[dict[str, object]]:
    budgets = []
    for row in range(21, 65):
        group = str(cell(cells, f"C{row}") or "").strip()
        if not group or group in {"Category", "TOTAL BILLS", "TOTAL DEBT PAYMENTS"}:
            continue
        budget = cell(cells, f"E{row}")
        actual = cell(cells, f"G{row}")
        if not isinstance(budget, (int, float)) and not isinstance(actual, (int, float)):
            continue
        if group in {"Income", "Bills", "Expenses", "Savings", "Debt"}:
            label = group
        else:
            label = group
        budgets.append(
            {
                "month": f"2026-{month_index:02d}",
                "category": label,
                "budget": round(float(budget or 0), 2) if isinstance(budget, (int, float)) else 0,
                "actualSnapshot": round(float(actual or 0), 2) if isinstance(actual, (int, float)) else 0,
            }
        )
    return budgets


def infer_accounts(opening_balance: float) -> list[dict[str, object]]:
    # The workbook's transaction table does not carry account names, so the hub starts
    # with editable account buckets and books imported rows against Deposits.
    return [
        {"id": "deposits", "name": "Deposits (Credit Union)", "openingBalance": 515.76, "currentBalance": 515.76, "displayOnDashboard": True, "notes": "Your Credit Union deposit account."},
        {"id": "wallet", "name": "Wallet Cash", "openingBalance": 0, "notes": "Cash carried in wallet."},
        {"id": "sinking-funds", "name": "Sinking Funds", "openingBalance": 0, "notes": "Total of envelope-style planned savings."},
        {"id": "cash-envelopes-home", "name": "Cash Envelopes At Home", "openingBalance": 139.5, "currentBalance": 139.5, "notes": "Physical cash envelopes stored at home."},
        {"id": "cibc", "name": "CIBC", "openingBalance": 0, "notes": "Your other bank account."},
        {"id": "undeposited-funds", "name": "Undeposited Funds", "openingBalance": 0, "displayOnDashboard": False, "notes": "Cash temporarily held before splitting to envelopes or sinking funds."},
    ]


def main() -> None:
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    with zipfile.ZipFile(input_path) as zf:
        shared = read_shared_strings(zf)
        sheets = read_sheet_map(zf)
        transactions = []
        budgets = []
        opening_balance = 0.0
        for short, _name, index in MONTHS:
            if short not in sheets:
                continue
            cells = read_cells(zf, sheets[short], shared)
            if short == "Jan":
                jan_rollover = unwrap(cells.get("E17"))
                opening_balance = float(jan_rollover or 0)
            transactions.extend(read_transaction_rows(cells, index))
            budgets.extend(read_budgets(cells, index))

    seed = {
        "meta": {
            "sourceWorkbook": input_path.name,
            "createdAt": datetime.now().isoformat(timespec="seconds"),
            "currency": "XCD",
            "budgetCycleStartDay": 24,
            "defaultViewMonth": "2026-06",
        },
        "accounts": infer_accounts(opening_balance),
        "transactions": transactions,
        "budgets": budgets,
        "envelopes": [
            {"id": "env-emergency", "name": "Emergency", "type": "Sinking Fund", "openingBalance": 0, "color": "#2d6a4f"},
            {"id": "env-birthday", "name": "Birthday", "type": "Sinking Fund", "openingBalance": 0, "color": "#b66b18"},
            {"id": "env-passport", "name": "Passport", "type": "Sinking Fund", "openingBalance": 0, "color": "#305f8f"},
            {"id": "env-groceries", "name": "Groceries", "type": "Cash Envelope", "openingBalance": 0, "color": "#226f76"},
            {"id": "env-bus", "name": "Bus", "type": "Cash Envelope", "openingBalance": 0, "color": "#8a4f7d"},
        ],
        "transfers": [],
        "loans": [
            {"id": "loan-main", "name": "Main Loan", "openingBalance": 203258.58, "subcategory": "Land", "color": "#a33d32"},
            {"id": "loan-insurance", "name": "Insurance", "openingBalance": 61159, "subcategory": "Insurance", "color": "#b66b18"},
        ],
    }
    output_path.write_text("window.BUDGET_SEED = " + json.dumps(seed, indent=2) + ";\n", encoding="utf-8")
    print(f"Wrote {output_path} with {len(transactions)} transactions and {len(budgets)} budget rows.")


if __name__ == "__main__":
    main()
